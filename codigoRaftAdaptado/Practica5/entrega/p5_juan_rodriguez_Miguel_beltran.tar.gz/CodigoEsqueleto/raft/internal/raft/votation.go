package raft

import (
	"errors"
	"fmt"
	"log"
	"raft/internal/comun/definitions"
	"raft/internal/comun/rpctimeout"
	"strconv"
	"time"
)

/*
	Metodo que inicia la votacion de una nueva candidatura
*/
func (nrf *NodoRaft) newVotation() {
	votes := make(chan definitions.ReplyRequestVote, len(nrf.Nodos)) // canal de respuesta de votos
	nrf.currentTerm = nrf.currentTerm + 1 // aumento mandato
	nrf.votedFor = nrf.Yo // indico que me autovoto
	for i, node := range nrf.Nodos { //Iniciamos unas conexion rpc para cada nodo
		if i != nrf.Yo {
			nrf.Logger.Println("send requestVote for:", node)
			go nrf.requestVoteOfNode(node, votes)
		}
	}
	nrf.waitForVotes(votes)
}

// Funcion para pedir un voto
func (nrf *NodoRaft) requestVoteOfNode(nodeRF rpctimeout.HostPort, votos chan definitions.ReplyRequestVote) {
	timeForReply := 300
	replyErr := definitions.ReplyRequestVote{0, false}

	var replay definitions.ReplyRequestVote
	//lasIndexNode := nrf.nextIndex[idnodo]
	lastLogIndex := len(nrf.logEntries) - 1
	termLastCommitEnty := nrf.getTermLastEnty() //extraigo el ultimo mandato indexado
	err := nodeRF.CallTimeout("NodoRaft.RequestVote", definitions.ArgsRequestVote{nrf.currentTerm,
		nrf.Yo, lastLogIndex, termLastCommitEnty}, &replay,
		time.Duration(timeForReply) * time.Millisecond) //estipular el tiempo
	if err != nil {
		votos <- replyErr
		log.Println("Timeout vote error:", err)
	} else {
		votos <- replay //introduzco la peticion al canal
	}
}


/**
	Metodo para esperar votos
	si mayoria estado = leader
	si no estado = follower
*/
func (nrf *NodoRaft) waitForVotes(votes chan definitions.ReplyRequestVote) {
	numVotes := 1         //1 por que cuento mi propio voto
loopWaitForVotes:
	for i := 0; i < len(nrf.Nodos) - 1; i++ { // espero la respuesta de los nodos
		select {
			case vote := <-votes:
				if vote.Granted { //compruebo si me han concedido el voto
					nrf.Logger.Println("Voto concedido : ", vote)
					numVotes++
				} else {
					nrf.Logger.Println("Voto no concedido : ", vote)
					nrf.checkCurrentTerm(vote.Term)
				}
		}
		if nrf.state == FOLLOWER {
			nrf.Logger.Println("Otro leader ha enviado heartbeat ")
			nrf.votedFor = -1
			return
		}
		if numVotes > len(nrf.Nodos)/2 { //Si obtengo mayoria soy el lider
			nrf.Logger.Println("Mayoria soy lider")
			nrf.state = LEADER
			nrf.changeConfigOfNewLeader()
			nrf.appendEntries()
			break loopWaitForVotes
		}
	}

	if numVotes <= len(nrf.Nodos)/2 { //si no tengo mayoria paso a seguidor
		fmt.Println("no mayoria")
		nrf.Logger.Println("No tengo mayoria vuelvo follower")
		nrf.state = FOLLOWER
		nrf.votedFor = -1
	}
}

/**
Metodo RPC a traves del cual se pide un voto
*/
func (nrf *NodoRaft) RequestVote(args *definitions.ArgsRequestVote, reply *definitions.ReplyRequestVote) error {
	nrf.Mux.Lock()
	if args.Term < nrf.currentTerm || (nrf.currentTerm == args.Term && nrf.votedFor != -1){ // si el mandato que me envian es menor al actual false y le paso el actual
		reply.Term = nrf.currentTerm
		reply.Granted = false
		nrf.Logger.Println("Response vote 1 : ", reply)
		return errors.New("Term of args less me: " + strconv.Itoa(nrf.Yo) + " term args: " +
			strconv.Itoa(args.Term) + " term me : "+ strconv.Itoa(nrf.currentTerm)) // check if errors
	}
	if args.Term > nrf.currentTerm {
		nrf.votedFor = -1
		nrf.currentTerm = args.Term
		if nrf.state != FOLLOWER {
			nrf.state = FOLLOWER
		}
	}
	isUpdate := nrf.checkLogRequest(args)
	if nrf.votedFor == -1 && isUpdate {
		nrf.currentTerm = reply.Term	//TOdO::MIRAR
		reply.Term = nrf.currentTerm
		reply.Granted = true
		nrf.votedFor = args.IdNode
	}else{
		reply.Term = nrf.currentTerm
		reply.Granted = false
	}
	nrf.Logger.Println("Response vote 2 : ", reply)
	fmt.Println("fin")
	nrf.Mux.Unlock()
	return nil
}

/**
	Metodo para comprobar si el log de la peticion esta por lo menos tan actualizado como el mio
*/
func (nrf *NodoRaft) checkLogRequest(args *definitions.ArgsRequestVote) bool {
	//Si el termino de la ultima peticion indexada es mayor que el suyo envio falso
	lastTermIndex := nrf.getTermLastEnty()
	if lastTermIndex > args.LastTermLog || (lastTermIndex == args.LastTermLog && (len(nrf.logEntries) - 1) > args.LastIndexLog){
		return false
	}
	//si no esta = de actualizado que el mio
	return true
}

func (nrf *NodoRaft) changeConfigOfNewLeader() {
	nrf.matchIndex = make([]int, len(nrf.Nodos))
	nrf.nextIndex = make([]int, len(nrf.Nodos))
	nrf.entriesVoted = make([]int, len(nrf.logEntries))
	for i := 0; i < len(nrf.nextIndex); i++ {
		nrf.nextIndex[i] = len(nrf.logEntries) //initialized to leader last log index + 1)
	}
	nrf.previousCommit = make([]chan bool, 0)
	for i := 0; i <= nrf.commitIndex + 1; i++ {
		chCommit := make(chan bool, 1)
		chCommit <- true
		nrf.previousCommit = append(nrf.previousCommit, chCommit)
	}
	chCommit := make(chan bool, 1)
	nrf.previousCommit = append(nrf.previousCommit, chCommit)
}

