// Escribir vuestro código de funcionalidad Raft en este fichero
//

package raft

//
// API
// ===
// Este es el API que vuestra implementación debe exportar
//
// nodoRaft = NuevoNodo(...)
//   Crear un nuevo servidor del grupo de elección.
//
// nodoRaft.Para()
//   Solicitar la parado de un servidor
//
// nodo.ObtenerEstado() (yo, mandato, esLider)
//   Solicitar a un nodo de elección por "yo", su mandato en curso,
//   y si piensa que es el msmo el lider
//
// nodoRaft.SometerOperacion(operacion interface()) (indice, mandato, esLider)

// type AplicaOperacion

import (
	"fmt"
	"io/ioutil"
	"log"
	"math/rand"
	"os"
	"raft/internal/comun/definitions"

	//"crypto/rand"
	"sync"
	"time"
	//"net/rpc"

	"raft/internal/comun/rpctimeout"
)


const (
	//  false deshabilita por completo los logs de depuracion
	// Aseguraros de poner kEnableDebugLogs a false antes de la entrega
	kEnableDebugLogs = true
	// Poner a true para logear a stdout en lugar de a fichero
	kLogToStdout = false
	// Cambiar esto para salida de logs en un directorio diferente
	kLogOutputDir = "./logs_raft/"
)

//Estados posibles de un lider
const (
	FOLLOWER  string = "follower"
	CANDIDATE        = "candidate"
	LEADER        = "leader"
)

// Tipo de dato Go que representa un solo nodo (réplica) de raft
//
type NodoRaft struct {
	Mux   sync.Mutex       // Mutex para proteger acceso a estado compartido
	Nodos []rpctimeout.HostPort	// Host:Port de todos los nodos (réplicas) Raft, en mismo orden
	Yo    int           // indice de este nodos en campo array "nodos"
	IdLider int
	Logger *log.Logger 	// Utilización opcional de este logger para depuración. Cada nodo Raft tiene su propio registro de trazas (logs)
	//  new vars
	state       string  //String que indica el estado (ya que la maq de estados no se implementa ahora)
	currentTerm int     //Mandato actual en el que estamos
	votedFor    int     //Id del nodo al que votaste en este mandato
	logEntries  []definitions.Entry //Entrada de registro = índice, mandato, comando

	hopeCommit []int
	commitIndex int //Indice del ultimo dato comprometido
	lastApplied int //Ultimo log enviado a la maq de estados (no se usa de momento)

	nextIndex  []int //Indice de la sig entrada a enviar a cada server (es del lider)
	matchIndex []int //Indice de la entrada mas alta recibida de cada server???

	entriesVoted []int
	/**********************************/

	/***** Vars para uso nuestro*/
	hearbeatChannel chan int //tengo que pensarlo
	previousCommit 	[]chan bool
	chanNewOperation chan definitions.TipoOperacion

	stateMachine *stateMachine
}



// Creacion de un nuevo nodo de eleccion
//
// Tabla de <Direccion IP:puerto> de cada nodo incluido a si mismo.
//
// <Direccion IP:puerto> de este nodo esta en nodos[yo]
//
// Todos los arrays nodos[] de los nodos tienen el mismo orden

// canalAplicar es un canal donde, en la practica 5, se recogerán las
// operaciones a aplicar a la máquina de estados. Se puede asumir que
// este canal se consumira de forma continúa.
//
// NuevoNodo() debe devolver resultado rápido, por lo que se deberían
// poner en marcha Gorutinas para trabajos de larga duracion
func NuevoNodo(nodos []rpctimeout.HostPort, yo int, 
						canalAplicarOperacion chan definitions.AplicaOperacion) *NodoRaft {
	nrf := generateNewNodo(nodos, yo) //Incializa el nodo Raft
	if kEnableDebugLogs {
		nombreNodo := nodos[yo].Host() + "_" + nodos[yo].Port()
		logPrefix := fmt.Sprintf("%s", nombreNodo)
		
		fmt.Println("LogPrefix: ", logPrefix)

		if kLogToStdout {
			nrf.Logger = log.New(os.Stdout, nombreNodo + " -->> ",
								log.Lmicroseconds|log.Lshortfile)
		} else {
			err := os.MkdirAll(kLogOutputDir, os.ModePerm)
			if err != nil {
				panic(err.Error())
			}
			logOutputFile, err := os.OpenFile(fmt.Sprintf("%s/%s.txt",
			  kLogOutputDir, logPrefix), os.O_RDWR|os.O_CREATE|os.O_TRUNC, 0755)
			if err != nil {
				panic(err.Error())
			}
			nrf.Logger = log.New(logOutputFile,
						   logPrefix + " -> ", log.Lmicroseconds|log.Lshortfile)
		}
		nrf.Logger.Println("logger initialized")
	} else {
		nrf.Logger = log.New(ioutil.Discard, "", 0)
	}

	// Añadir codigo de inicialización

	go nrf.loop()	// Inicia el loop del nodo
	go nrf.checkForApplyOperation()
	return nrf
}
/*+
Metodo que inicializa un nodo raft
*/
func generateNewNodo(nodos []rpctimeout.HostPort, yo int) *NodoRaft {
	nrf := &NodoRaft{}
	nrf.Nodos = nodos
	nrf.Yo = yo
	nrf.IdLider = -1
	nrf.Logger = &log.Logger{}
	nrf.currentTerm = 0                     //Al inicio termino = 0
	nrf.state = FOLLOWER                     // Inicio estado seguidor
	nrf.votedFor = -1                        // -1 = none
	nrf.logEntries = make([]definitions.Entry, 0)//slice of entry with 0
	nrf.commitIndex = -1                     // init 0 commit entries ; -1 = ninguna entrada registrada
	nrf.lastApplied = -1                     // 0 entries run in state machine; -1 = ninguna entrada aplicada


	nrf.nextIndex = make([]int, len(nodos))  //generate a slice with leng(nodos) for save the last entry
	nrf.matchIndex = make([]int, len(nodos)) //last index for match with the slice of leader

	nrf.entriesVoted = make([]int, 0) //canal de votos para commitear
	//canal de heartbeat
	nrf.hearbeatChannel = make(chan int, 100)

	nrf.hopeCommit = make([]int, 1)

	//Estructura para comprometer entradas correctamente
	nrf.previousCommit = append(nrf.previousCommit, make(chan bool, 1))
	nrf.previousCommit[0] <- true

	nrf.chanNewOperation = make(chan definitions.TipoOperacion, 20)

	nrf.stateMachine = newStateMachine()
	return nrf
}

/*
	Bucle para comprobar el estado actual
*/
func (nrf *NodoRaft) loop() {
	go func() {
		for  { //Thread para mostrar estado
			select {
			case <-time.After(time.Second * 10):
				nrf.Logger.Println("Estado: " ,nrf.state, " Log: ", nrf.logEntries)
				//fmt.Println("Estado: " ,nrf.state, " Log: ", nrf.logEntries, " votes ", nrf.entriesVoted, " commited ", nrf.commitIndex)
				fmt.Println("Estado: " ,nrf.state, " Log: ", nrf.logEntries, " commited ", nrf.commitIndex)
			}
		}
	}()
	for  {
		//nrf.Logger.Println("Estado: " ,nrf.state)
		//fmt.Println("ENtro ", nrf.state)
		switch nrf.state {//Automata de estados
			case FOLLOWER:
				nrf.runFollower() //Gestiones realizadas por seguidor
			case CANDIDATE:
				nrf.newVotation() // gestiones realizadas por un candidato
			case LEADER:
				nrf.runLeader()  // Definir
		}
	}
}

/*
	Metodo para realizar las acciones del cliente
*/
func (nrf *NodoRaft) runFollower() {
	rand.Seed(time.Now().UnixNano() + rand.Int63()) //update seed
/*	min := 150
	max := 300
*/
	min := 5000
	max := 8500

	timeout :=  time.Duration(rand.Intn(max - min) + min) * time.Millisecond // Timeout de espera de latido
	select {
		case <-nrf.hearbeatChannel:
			nrf.Logger.Println("hearbeat")
			//Gestion de heartbeat Todo: Mirar
		case <-time.After(timeout):
			nrf.Logger.Println("Timeout follower")
			nrf.state = CANDIDATE //Si no recibimos latidos cambiamos a candidato
	}
}

/*
	Funcion para gestionar al lider
*/
func (nrf *NodoRaft) runLeader() {
	timeoutHeartbeat := 500
	timeout := time.Duration(timeoutHeartbeat) * time.Millisecond
	select {
	case operation := <-nrf.chanNewOperation:
		//nrf.Logger.Println("LLega operacion: ", operation )
		nrf.addEntryToLogEntries(operation)
		nrf.appendEntries()
		break
	case <-time.After(timeout):
		//nrf.Logger.Println("***** HeartBeat ")
		nrf.appendEntries()
		break
	}
}



// -----------------------------------------------------------------------
// LLAMADAS RPC al API
//
// Si no tenemos argumentos o respuesta estructura vacia (tamaño cero)
type Vacio struct{}

func (nrf * NodoRaft) ParaNodo(args Vacio, reply *Vacio) error {
	defer nrf.para()
	return nil
}


func (nrf *NodoRaft) ObtenerEstadoNodo(args *Vacio, reply *definitions.EstadoRemoto) error {
	reply.IdNodo, reply.Term, reply.IsLeader, reply.IdLeader = nrf.obtenerEstado()
	return nil
}


func (nrf *NodoRaft) SometerOperacionRaft(operacion definitions.TipoOperacion,
												reply *definitions.ResultadoRemoto) error {
	reply.IndiceRegistro,reply.Term, reply.IsLeader,
			reply.IdLeader,reply.ValorADevolver = nrf.someterOperacion(operacion)
	return nil
}





// El servicio que utilice Raft (base de datos clave/valor, por ejemplo)
// Quiere buscar un acuerdo de posicion en registro para siguiente operacion
// solicitada por cliente.

// Si el nodo no es el lider, devolver falso
// Sino, comenzar la operacion de consenso sobre la operacion y devolver en
// cuanto se consiga
//
// No hay garantia que esta operacion consiga comprometerse en una entrada de
// de registro, dado que el lider puede fallar y la entrada ser reemplazada
// en el futuro.
// Primer valor devuelto es el indice del registro donde se va a colocar
// la operacion si consigue comprometerse.
// El segundo valor es el mandato en curso
// El tercer valor es true si el nodo cree ser el lider
// Cuarto valor es el lider, es el indice del líder si no es él
func (nrf *NodoRaft) someterOperacion(operacion definitions.TipoOperacion) (int, int,
	bool, int, string) {
	indice := -1
	mandato := -1
	IsLeader := false
	idLider := -1
	valorADevolver := ""


	// Si soy lider recibo la operacion
	if nrf.isLeader() {
	//	nrf.Logger.Println("Recibo operacion ", operacion)
		IsLeader = true
		nrf.chanNewOperation <- operacion							// Todo: Hacer para esperar a la mayoria
	}else{
		//nrf.Logger.Println("mi lider es ", nrf.IdLider)
		idLider = nrf.IdLider //devuelvo el lider en cuestion
		IsLeader = false
	}

	return indice, mandato, IsLeader, idLider, valorADevolver
}


func (nrf *NodoRaft) ObtenerEntriesNodo(args *Vacio, reply *definitions.EstadoEntriesRemoto) error {
	reply.Entries = nrf.logEntries
	reply.CommitIndex = nrf.commitIndex
	return nil
}

